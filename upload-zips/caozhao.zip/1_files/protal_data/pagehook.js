/*!
 * Page qf.com page-initializer - v1.0.0 (2015-09-23T11:32:47+0800)
 * Copyright 2005-2015 56.com
 */

window.pageHook = (function(window) { 'use strict';

//是否PC客户端
var isClient = window.isClient = window.navigator.userAgent.indexOf('QianFan') !== -1;

//替换域名
var isReplaceHost = location.href.indexOf('useSuperLink') !== -1,
	REPLACE_HOST = location.host + '/fefiles';

//var BASIC_URL = 'http://file{n}.qf.56.itc.cn/';
var BASIC_URL = '//file.qf.56.com/f/';

var footerScript = {
	standard: 'style/common/footer/v2/footer_v.2.js'
};

var statScript = '//file.qf.56.com/f/script/fn/stat/v1/stat.js',
	layoutScript = 'script/lib/layout/layout-1.0.0.js',
	miniHeaderCSSClass = 'h_mini',
	sMiniHeaderCSSClass = 'h_s_mini';

// 默认配置
var config = {
	TIMESTAMP: '20160527a',
	basicStyle: 'style/common/base/v2/css/base_v.2.0.css',
	headerScript: 'style/common/header/v2/header_v.1.js',
	footerScript: footerScript.standard,
	beforeHeadEnd: ['//file.qf.56.com/f/script/static/bowl/bowl_v2.js'],
	afterBodyStart: [ ],
	beforeBodyEnd: ['//a1.itc.cn/pv/js/spv.1305141919.js'],
	adaptiveHeader: '21'
};

var clientConfig = {
	basicStyle: 'style/client/common/base/v1/css/client_base_v.1.0.css'
};

//处理页面频道参数
var _page_;
if ('undefined' === typeof window._page_) {
	_page_ = window._page_ = {};
} else { 
	_page_ = window._page_;
}

function getHost(url) {
	var a = document.createElement('a');
	a.href = url;

	return a.host;
}


// 判断是否数组
function isArray(value) {
	return Object.prototype.toString.call(value) === '[object Array]';
}

//判断是否对象
function isObject(value) { 
	return Object.prototype.toString.call(value) === '[object Object]';
}

// 获取URL中的扩展名
function getExtName(url) {
	var a = document.createElement('a');
	a.href = url;

	var pathname = a.pathname.split('/');
	pathname = pathname[pathname.length - 1];

	if (pathname) {
		pathname = pathname.split('.');
		return pathname[pathname.length - 1].toLowerCase();
	}
}


// 输出引用CSS的HTML标签
function writeCSS(options) {
	var html = '<link href="' + options.url + '"';

	var attrs = {
		rel: 'stylesheet',
		type: 'text/css'
	};
	if (options.attrs) {
		for (var a in options.attrs) {
			attrs[a] = options.attrs[a];
		}
	}

	for (var a in attrs) {
		if (attrs[a] != null) {
			html += ' ' + a + '="' + attrs[a] + '"';
		}
	}
	html += ' />'

	document.write(html);
}

// 输出引用JS的HTML标签
function writeScript(options) {
	document.write('<script src="' + options.url + '"></script>');
}


// 用于计算采用哪个主机名，从file2开始
var n = 2, nCounter = 0;
// 执行指定的JS
function execLines(lines) {
	for (var i = 0, l; i < lines.length; i++) {
		l = lines[i];
		if (!l) { continue; }

		// 把字符串统一为对象处理
		if (typeof l === 'string') {
			l = { url: l };
		}

		switch (typeof l) {
			// 函数，直接执行
			case 'function':
				l();
				break;

			case 'object':
				// 没有指定协议的情况下，添加默认主机名
				if ( !/^(?:[a-z]+:)?\/\//i.test(l.url) ) {
					// 拼接主机名
					l.url = BASIC_URL.replace('{n}', n) + l.url.replace(/^\/+/, '');
					//l.url = BASIC_URL + l.url.replace(/^\/+/, '');
					// 加上时间戳
					l.url += (l.url.indexOf('?') !== -1 ? '&' : '?') + config.TIMESTAMP;

					// 每个主机名用4次，然后更换成下一个
					nCounter++;
					if ( !(nCounter % 5) ) {
						n++;
						if (n > 4) { n = 1; }
					}
				}

				// 符合域名替换条件
				if (isReplaceHost) {
					l.url = l.url.replace(getHost(l.url), REPLACE_HOST);
				}

				if (getExtName(l.url) === 'css') {
					writeCSS(l);
				} else {
					// 默认以script输出
					writeScript(l);
				}
				break;
		}
	}
}

//根据页面_page_.channel组合输出文件
function genOutPutArr(obj) { 
	if (isObject(obj)) {
		if (typeof _page_.channel === 'undefined') { throw new Error('please specify _page_.channel for this page'); return; }

		var tmp = obj.all;
		obj = tmp.concat(obj[_page_.channel]);
	} 

	return obj;
}


return {
	/**
	 * 修改配置
	 * @method config
	 * @param {Object} newConfig 新配置
	 *   @param {String} [newConfig.TIMESTAMP] 文件时间戳
	 *   @param {String} [newConfig.basicStyle] 基础样式文件
	 *   @param {String} [newConfig.headerScript] 页头脚本文件
	 *   @param {String} [newConfig.footerScript] 页脚脚本文件
	 *   @param {String} [newConfig.headerType] 页头类型，standard（大页头）、mini（小页头）或s_mini（小小页头）。
	 *     默认为standard
	 *   @param {String} [newConfig.footerType] 页脚类型，standard（大页脚）或mini（小页脚）。
	 *     默认为standard
	 *   @param {Array|String|Function|Object} [newConfig.beforeHeadEnd] 指定head标签结束前执行的脚本(object时，页面需要设置_page_.channel，以下同)
	 *   @param {Array|String|Function|Object} [newConfig.afterBodyStart] 指定body标签开始后执行的脚本
	 *   @param {Array|String|Function|Object} [newConfig.beforeBodyEnd] 指定body标签结束前执行的脚本
	 *   @param {String} [newConfig.insertType='after'] 指定上述三个区域脚本的添加方式。
	 *     after为在原有的脚本后添加；
	 *     before为在原有的脚本前添加；
	 *     replace为替换原有脚本。
	 *     初始值为after。
	 *   @param {String} [newConfig.adaptiveHeader] 页头自适应方式。
	 *     为空时完全不进行自适应；
	 *     为两位数字时，第一位为0时表示强制窄屏，为1时表示强制宽屏，为2时进行宽窄屏宽度自适应;
	 *     				第二位为1时表示是否滚动超过一定距离时固定。
	 *     初始值为21
	 *   @param {String|Boolean} [newConfig.statInfo] PV统计参数信息。为false时不发送统计
	 */
	config: function(newConfig) {
		var propNames, propName, tmp, i;

		// 时间戳
		config.TIMESTAMP = newConfig.TIMESTAMP ? newConfig.TIMESTAMP : config.TIMESTAMP;
		// for jraiser
		window.___script___ = { TIMESTAMP: config.TIMESTAMP };

		// 配置 基本样式文件/页头脚本/页脚脚本, 直接替换
		propNames = ['basicStyle', 'headerScript', 'footerScript'];
		for (i = 0; propName = propNames[i]; i++) {
			if (propName in newConfig) {
				config[propName] = newConfig[propName];
			}
		}

		// 页脚类型
		if ('footerType' in newConfig) {
			config.footerScript = footerScript[newConfig.footerType];
		}
		// 页头类型
		config.headerType = newConfig.headerType;

		// 统计参数
		config.statInfo = newConfig.statInfo;

		// 页头自适应方式
		if ('adaptiveHeader' in newConfig) {
			config.adaptiveHeader = newConfig.adaptiveHeader;
		}

		// 配置三个区域执行的脚本
		propNames = ['beforeHeadEnd', 'afterBodyStart', 'beforeBodyEnd'];
		for (i = 0, tmp; propName = propNames[i]; i++) {
			if (propName in newConfig) {
				tmp = genOutPutArr(newConfig[propName]);
				if ( !isArray(tmp) ) { tmp = [tmp]; }
 
				switch (newConfig.insertType) {
					case 'before':
						// 插入到原数组之前
						config[propName] = tmp.concat(config[propName]);
						break;

					case 'replace':
						// 替换原数组
						config[propName] = tmp.slice();
						break;

					default:
						// 插入到原数组之后
						config[propName] = config[propName].concat(tmp);
				}
			}
		}
	},

	/**
	 * 执行head标签结束前的脚本
	 * @method beforeHeadEnd
	 */
	beforeHeadEnd: function() {
		var lines = [config.basicStyle].concat(config.beforeHeadEnd);

		if (config.adaptiveHeader) { lines.push(layoutScript); }
		if (isClient) { lines.push(clientConfig.basicStyle); }

		return execLines(lines);
	},

	/**
	 * 执行body标签开始后的脚本
	 * @method afterBodyStart
	 */
	afterBodyStart: function() {
		var wrap = document.getElementById('wrap');
		// 小头，在wrap上加个class
		if (wrap && config.headerType) {
			var className = wrap.className, miniHeaderClass;

			switch(config.headerType) {
				case 'mini':
					miniHeaderClass = miniHeaderCSSClass;
					break;
				case 's_mini':
					miniHeaderClass = sMiniHeaderCSSClass;
					break;
			}

			if (className) {
				if ( (' ' + className + ' ').indexOf(' ' + miniHeaderClass + ' ') === -1 ) {
					wrap.className += ' ' + miniHeaderClass;
				}
			} else {
				wrap.className = miniHeaderClass;
			}
		}

		var lines = [config.headerScript].concat(config.afterBodyStart),
			adaptiveHeader = String(config.adaptiveHeader || '');

		if (adaptiveHeader) {
			lines.push(function() {
				var layout = window.layout,
					bodyWrap = document.body,
					bodyClass = bodyWrap.className;

				if (layout) {
					if(adaptiveHeader.charAt(0) == 0){
						if (bodyClass) {
							bodyWrap.className += ' s_screen';
						} else {
							bodyWrap.className = 's_screen';
						}
					} else if (adaptiveHeader.charAt(0) == 1) {
						if (bodyClass) {
							bodyWrap.className += ' b_screen';
						} else {
							bodyWrap.className = 'b_screen';
						}
					} else if(adaptiveHeader.charAt(0) == 2){
						layout.onPageResize(function(size, helper) {
							helper[
								(size.width < 1660 && size.width >= 1346) ? 'addClass' : 'removeClass'
							](document.body, 'b_screen');
							helper[
								(size.width < 1346 && size.width >= 1260) ? 'addClass' : 'removeClass'
							](document.body, 'm_screen');
							helper[
								size.width < 1260 ? 'addClass' : 'removeClass'
							](document.body, 's_screen');
							helper[
								size.width < 980 ? 'addClass' : 'removeClass'
							](document.body, 's_screen_c');
						});
					}
					if (adaptiveHeader.charAt(1) == 1 && config.headerType !== 's_mini') {
						if (navigator.userAgent.indexOf('MSIE 6') === -1) {
							if (wrap) {
								layout.onPageScroll(function(scrollLength, helper) {
									helper[
										scrollLength.top > 60 ? 'addClass' : 'removeClass'
									](wrap, 'h_main_fixed');
								});
							}
						}
					} else if (adaptiveHeader.charAt(1) == 0) { 
						if (wrap) {
							layout.onPageScroll(function(scrollLength, helper) {
								helper[
									scrollLength.top > 1 ? 'addClass' : 'removeClass'
								](wrap, 'h_main_static');
							});
						}
					}
				}
			});
		}

        //客户端body添加类
		isClient && (document.body.className += ' qf_client');

		return execLines(lines);
	},

	/**
	 * 执行body标签结束前的脚本
	 * @method beforeBodyEnd
	 */
	beforeBodyEnd: function() {
		var lines = [config.footerScript].concat(config.beforeBodyEnd);
		if (config.statInfo !== false) {
			window.statInfo = config.statInfo;
			lines = lines.concat(statScript);
		}

		return execLines(lines);
	}
};

})(window);
