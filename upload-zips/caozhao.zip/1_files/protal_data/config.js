/* 配置项 */
pageHook.config({
    statInfo: {
        statId: 'qfsy'
    },
    adaptiveHeader: '21',
	beforeHeadEnd: [
	   '//file.qf.56.com/f/script/ui/outputFixedPng.min.js', 
		'style/home/v2/css/home_v.2.css',
		'style/client/home/v1/css/client_home_v.1.css'
	]
});
